//---------------------------------------------------------
// file:	main.c
// author:	Anthony Miller
// email:	Anthony.m@digipen.edu
// course:	GAM100-F18-D
//
// brief:	Main entry point for the sample project
//			of the C_Processing library
//
// Copyright � 2018 DigiPen, All rights reserved.
//---------------------------------------------------------

#include <windows.h>
#include "C_Processing.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define START 0
#define MOVING 1
#define MOVED 2
#define MENU 3
#define PLAYING 4
#define END 5

/*prototypes*/
void start(void);
void moving(void);
void moved(void);
void drawSparkle(float x, float y, float offSet);
void menu(void);
void playing(void);
void end(void);

float rectX;            //x position of rectangle to collect
float rectY;            //y position of rectangle to collect
int score = START;      //how many rectangles have been collected
float offSet;           // variable to move the logo from the center
PSound snare;           //holds the sound of a snare
int gameState = START;  //gamestate
PImage logo;            //digipen logo holder
float sparkX1;   //declaring the holders for sparkle locations
float sparkY1;
float sparkX2;
float sparkY2;
float sparkX3;
float sparkY3;
float sparkX4;
float sparkY4;
float sparkX5;
float sparkY5;


// when used with Run() this function will be called once at the beginning of the program
void init()
{
	//set the resolution to 1000x800
	size(1200, 800);

  //fullscreen();

  noStroke();

	//set the snare variable to the snare sound file
	snare = loadSound("./Assets/Snare.wav", 0);
	
}

// when used with Run() this function will be called repeatedly every frame
void update()
{
  switch (gameState)
	{	
		case START :
      start();
      break;
			
		case MOVING :
      moving();
			break;

    case MOVED:
      moved();
      break;

    case MENU:
      menu();
      break;

		case PLAYING :
      playing();
      break;

    case END:
      end();
      break;
	}
}

// main() the starting point for the program
// Run() is used to tell the program which init and update functions to use.
int main(void)
{    
    Run(init, update);
    return 0;
}

/**/
void start(void)
{
  //load digipen logo
  logo = loadImage("./Assets/DigiPen_RED_1024px.png");

  //display digipen logo
  image(logo, windowWidth / 2.0f, windowHeight / 2.0f,
    windowWidth / 2.0f - 20.0f, 280.0f);

  //start logo animation after 3 seconds
  if (3 < second())
  {
    offSet = 0.0f;
    gameState = MOVING;
  }
}

/**/
void moving(void)
{
  //set displacment of image
  if (((windowWidth / 2.0f) - offSet) > windowWidth / 4.0f)
  {
    offSet++;
  }

  //set background to black
  backgroundColor(color(0, 0, 0, 255));

  //display digipen logo left
  image(logo, (windowWidth / 2.0f) - offSet, windowHeight / 2.0f,
    (windowWidth / 2.0f) - 20.0f, 280.0f);

  //display digipen logo right
  image(logo, (windowWidth / 2.0f) + offSet - 7.0f, windowHeight / 2.0f - 7.0f,
    (windowWidth / 2.0f) - 20.0f, 290.0f);

  //no boarder on drawn objects
  //noStroke();

  //when mouse is clicked, start the game
  if (mouseClicked())
  {
	  //set first square to collect
	  rectX = (float)random() * (windowWidth - 50.0f);
	  rectY = (float)random() * (windowHeight - 25.0f);
	  gameState = PLAYING;
  }
  if (offSet >= windowWidth / 4.0f)
  {
	  gameState = MOVED;
  }
}

/*draws sparkles in random places around the digipen logo*/
void moved(void)
{
  //holder variable for triangle offsets
  int holder;

	//set background to black
	backgroundColor(color(0, 0, 0, 255));
	
		//set position of first sparkle
		if ((int)second() % 10 == 0)
		{
			sparkX1 = (float)random() * (windowWidth / 2.0f);
			sparkY1 = ((float)random() * ((windowHeight / 2.0f)) + (windowHeight / 4.0f));
		}

		//draw first sparkle
		if ((int)second() % 10 > 0)
		{
      //set color of sparkle to white
      fillColor(color(255, 255, 255, 255 / ((int)second() % 10)));
      holder = (int)second() % 10;
      drawSparkle(sparkX1, sparkY1, (float)holder);
		}

    //set position for fourth sparkle
    if ((int)second() % 8 == 0)
    {
      sparkX4 = (float)random() * (windowWidth / 2.0f);
      sparkY4 = ((float)random() * ((windowHeight / 2.0f)) + (windowHeight / 4.0f));
    }

    //draw second sparkle
    if ((int)second() % 8 > 0)
    {
      //set color of sparkle to white
      fillColor(color(255, 255, 255, 255 / ((int)second() % 8)));

      holder = (int)second() % 8;
      //draw the sparkle
      drawSparkle(sparkX4, sparkY4, (float)holder);
    }

		//set position of third sparkle
		if ((int)second() % 6 == 0)
		{
			sparkX3 = (float)random() * (windowWidth / 2.0f);
			sparkY3 = ((float)random() * ((windowHeight / 2.0f)) + (windowHeight / 4.0f));
		}

		//draw third sparkle
		if ((int)second() % 6 > 0)
		{
      //set color of sparkle to white
      fillColor(color(255, 255, 255, 255 / ((int)second() % 6)));

      holder = (int)second() % 6;
      //draw the sparkle
      drawSparkle(sparkX3, sparkY3, (float)holder);
		}

		//display digipen logo left
		image(logo, (windowWidth / 2.0f) - offSet, windowHeight / 2.0f,
			(windowWidth / 2.0f) - 20.0f, 280.0f);

		//display digipen logo right
		image(logo, (windowWidth / 2.0f) + offSet - 6.0f, windowHeight / 2.0f - 6.0f,
			(windowWidth / 2.0f) - 20.0f, 290.0f);

    //set position of second sparkle
    if ((int)second() % 5 == 0)
    {
      sparkX2 = (float)random() * (windowWidth / 2.0f);
      sparkY2 = ((float)random() * ((windowHeight / 2.0f)) + (windowHeight / 4.0f));
    }

    //draw second sparkle
    if ((int)second() % 5 > 0)
    {
      //set color of sparkle to white
      fillColor(color(255, 255, 255, 255 / ((int)second() % 5)));
      holder = (int)second() % 5;
      drawSparkle(sparkX2, sparkY2, (float)holder);
    }

		//set position of fourth sparkle
		if ((int)second() % 4 == 0)
		{
			sparkX5 = (float)random() * (windowWidth / 2.0f);
			sparkY5 = ((float)random() * ((windowHeight / 2.0f)) + (windowHeight / 4.0f));
		}

		//draw fourth sparkle
		if ((int)second() % 4 > 0)
		{
      //set color of sparkle to white
      fillColor(color(255, 255, 255, 255 / ((int)second() % 4)));

      holder = (int)second() % 4;
      //draw the sparkle
      drawSparkle(sparkX5, sparkY5, (float)holder);
		}

	//draw things in 3d using the by off setting the right screen by 7 pixels up and left
	//bigger the offset, the further back the object will be
	//have little objects come zooming in

	//when mouse is clicked, start the game
	if (mouseClicked())
	{
		//set first square to collect
		rectX = (float)random() * (windowWidth - 50.0f);
		rectY = (float)random() * (windowHeight - 25.0f);
		gameState = PLAYING;
	}
}

/**/
void drawSparkle(float x, float y, float change)
{
  //draw sparkle on left side
  triangle(x - 4.0f - change, y - 9.0f - change,  // point 1
    x + 9.0f + (change * 1.5f), y,  // point 2
    x - 4.0f - change, y + 9.0f + change); // point 3
  triangle(x - 9.0f - (change * 1.5f), y,  // point 1
    x + 4.0f + change, y - 9.0f - change,  // point 2
    x + 4.0f + change, y + 9.0f + change); // point 3

  //draw sparkle on right side
  triangle(x - 4.0f + (windowWidth / 2.0f) - 10.0f - change, y - 9.0f - 10.0f - change,  // point 1
    x + 9.0f + (windowWidth / 2.0f) - 10.0f + (change * 1.5f), y - 10.0f,  // point 2
    x - 4.0f + (windowWidth / 2.0f) - 10.0f - change, y + 9.0f - 10.0f + change); // point 3
  triangle(x - 9.0f + (windowWidth / 2.0f) - 10.0f - (change * 1.5f), y - 10.0f,  // point 1
    x + 4.0f + (windowWidth / 2.0f) - 10.0f + change, y - 9.0f - 10.0f - change,  // point 2
    x + 4.0f + (windowWidth / 2.0f) - 10.0f + change, y + 9.0f - 10.0f + change); // point 3
}

/*the menu system*/
void menu(void)
{

}

/**/
void playing(void)
{
  //gets rid of the cursor while it is in the screen
  noCursor();

  //set background to green
  backgroundColor(color(0, 255, 0, 255));

  //draws a blue circle where the mouse is
  //int mPositionX = mouseX;
  //int mPositionY = mouseY;
  fillColor(color(0, 0, 255, 255));
  circle(mouseX, mouseY, 5.0f);

  //reset where the block is when one is collected and increase the score
  if ((rectX <= mouseX + 10.0f && mouseX - 10.0f <= rectX + 50.0f) && (rectY <= mouseY + 10.0f && mouseY - 10.0f <= rectY + 25.0f))
  {
    rectX = (float)random() * (windowWidth - 50.0f);
    rectY = (float)random() * (windowHeight - 25.0f);
    score++;
    printf("score: %d\n", score);
    sound(snare);
  }

  //draw the block to collect
  fillColor(color(252, 0, 0, 255));
  rect(rectX, rectY, 50.0f, 25.0f);


  //set up text font
  textFont(loadFont("./Assets/Exo2-Regular.ttf"), 20.0);

  //display the score
  textBox("Score: %d", 20.0f, windowWidth - 50.0f, 5.0f);
}

/**/
void end(void)
{

}