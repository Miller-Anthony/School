//---------------------------------------------------------
// file:	GameManager.c
// author:	Anthony Miller
// brief:	Game Over scene functions
//
// Copyright � 2018 DigiPen, All rights reserved.
//---------------------------------------------------------

#include "C_Processing.h"
#include "GameManager.h"

//---------------------------------------------------------
// Private Consts:
//---------------------------------------------------------

//---------------------------------------------------------
// Private Structures:
//---------------------------------------------------------

//---------------------------------------------------------
// Public Variables:
//---------------------------------------------------------
static int score;					//stores the overall score for the current game
static int energy;					//stores amount of energy for shooting
static float bullets[100];          //stores the coordinates of all the bullets
static float astroids[100];			//stores the coordinates of all the astroids

//---------------------------------------------------------
// Private Variables:
//---------------------------------------------------------

//---------------------------------------------------------
// Private Function Declarations:
//---------------------------------------------------------

//---------------------------------------------------------
// Public Functions:
//---------------------------------------------------------

int getScore()
{
	return score;
}

void incrementScore()
{
	score++;
}

void resetScore()
{
	score = 0;
}

int getEnergy()
{
	return energy;
}

void incrementEnergy()
{
	energy++;
}

void decrementEnergy()
{
	energy--;
}

void resetEnergy()
{
	energy = 0;
}

float getShotX(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return 0;
	}
	return bullets[iteration];
}

float getShotY(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return 0;
	}
	return bullets[iteration + 1];
}

void setShot(int iteration, float x, float y)
{
	if (iteration < 0 || iteration > 98)
	{
		return;
	}
	bullets[iteration] = x;
	bullets[iteration + 1] = y;
}

void moveShot(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return;
	}
	bullets[iteration + 1] -= 3;
}

float getAstroidX(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return 0;
	}
	return astroids[iteration];
}

float getAstroidY(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return 0;
	}
	return astroids[iteration + 1];
}

void setAstroid(int iteration, float x, float y)
{
	if (iteration < 0 || iteration > 98)
	{
		return;
	}
	astroids[iteration] = x;
	astroids[iteration + 1] = y;
}

void moveAstroid(int iteration)
{
	if (iteration < 0 || iteration > 98)
	{
		return;
	}
	astroids[iteration + 1] += 3;
}
//---------------------------------------------------------
// Initialize the game value.
void GameManagerInit()
{
	score = 0;
	energy = 0;
}

//---------------------------------------------------------
// Private Functions:
//---------------------------------------------------------

